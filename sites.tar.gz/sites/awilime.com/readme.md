# awilime.com

https://www.awilime.com/tv/musor

### Download the guide

```sh
npm run grab -- --site=awilime.com
```

### Update channel list

```sh
npm run channels:parse -- --config=./sites/awilime.com/awilime.com.config.js --output=./sites/awilime.com/awilime.com.channels.xml
```

### Test

```sh
npm test -- awilime.com
```
