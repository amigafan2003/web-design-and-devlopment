# directv.com.ar

https://directv.com.ar/ _[Geo-blocked]_

### Download the guide

```sh
npm run grab -- --site=directv.com.ar
```

### Test

```sh
npm test -- directv.com.ar
```
