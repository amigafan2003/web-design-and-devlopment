# flixed.io

https://flixed.io/tv-guide

### Download the guide

```sh
npm run grab -- --site=flixed.io
```

### Test

```sh
npm test -- flixed.io
```
