# comteco.com.bo

https://www.comteco.com.bo/pages/canales-y-programacion-tv/

### Download the guide

```sh
npm run grab -- --site=comteco.com.bo
```

### Test

```sh
npm test -- comteco.com.bo
```
