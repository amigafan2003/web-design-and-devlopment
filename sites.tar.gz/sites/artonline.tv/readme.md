# artonline.tv

https://www.artonline.tv/guide/1

### Download the guide

```sh
npm run grab -- --site=artonline.tv
```

### Test

```sh
npm test -- artonline.tv
```
