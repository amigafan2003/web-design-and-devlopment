# directv.com.uy

https://directv.com.uy/ _[Geo-blocked]_

### Download the guide

```sh
npm run grab -- --site=directv.com.uy
```

### Test

```sh
npm test -- directv.com.uy
```
