# knr.gl

https://knr.gl/kl/tv/aallakaatitassat

### Download the guide

```sh
npm run grab -- --site=knr.gl
```

### Test

```sh
npm test -- knr.gl
```
