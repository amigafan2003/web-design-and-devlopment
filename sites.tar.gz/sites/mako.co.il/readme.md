# mako.co.il

https://www.mako.co.il/tv-tv-schedule

### Download the guide

```sh
npm run grab -- --site=mako.co.il
```

### Test

```sh
npm test -- mako.co.il
```
