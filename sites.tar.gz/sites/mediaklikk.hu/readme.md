# mediaklikk.hu

https://mediaklikk.hu/

### Download the guide

```sh
npm run grab -- --site=mediaklikk.hu
```

### Test

```sh
npm test -- mediaklikk.hu
```
