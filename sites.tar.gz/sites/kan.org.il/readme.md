# kan.org.il

https://kan.org.il/ _[Geo-blocked]_

### Download the guide

```sh
npm run grab -- --site=kan.org.il
```

### Test

```sh
npm test -- kan.org.il
```
