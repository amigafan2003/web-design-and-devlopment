# 9tv.co.il

https://www.9tv.co.il/BroadcastSchedule

### Download the guide

```sh
npm run grab -- --site=9tv.co.il
```

### Test

```sh
npm test -- 9tv.co.il
```
