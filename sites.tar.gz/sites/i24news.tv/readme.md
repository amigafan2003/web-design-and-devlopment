# i24news.tv

https://www.i24news.tv/en/schedules

### Download the guide

```sh
npm run grab -- --site=i24news.tv
```

### Test

```sh
npm test -- i24news.tv
```
