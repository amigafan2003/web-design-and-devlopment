# mediasetinfinity.mediaset.it

https://mediasetinfinity.mediaset.it/ _[Geo-blocked]_

### Download the guide

```sh
npm run grab -- --site=mediasetinfinity.mediaset.it
```

### Test

```sh
npm test -- mediasetinfinity.mediaset.it
```
