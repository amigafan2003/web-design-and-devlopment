# andorradifusio.ad

https://andorradifusio.ad/programacio/atv

### Download the guide

```sh
npm run grab -- --site=andorradifusio.ad
```

### Test

```sh
npm test -- andorradifusio.ad
```
