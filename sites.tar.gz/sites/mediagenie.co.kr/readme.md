# mediagenie.co.kr

https://mediagenie.co.kr/

### Download the guide

```sh
npm run grab -- --site=mediagenie.co.kr
```

### Test

```sh
npm test -- mediagenie.co.kr
```
