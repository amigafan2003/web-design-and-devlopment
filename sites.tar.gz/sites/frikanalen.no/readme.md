# frikanalen.no

https://frikanalen.no/schedule

### Download the guide

```sh
npm run grab -- --site=frikanalen.no
```

### Test

```sh
npm test -- frikanalen.no
```
