# kvf.fo

https://kvf.fo/nskra/sv

### Download the guide

```sh
npm run grab -- --site=kvf.fo
```

### Test

```sh
npm test -- kvf.fo
```
