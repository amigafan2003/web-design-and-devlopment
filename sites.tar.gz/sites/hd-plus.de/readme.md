# hd-plus.de

https://hd-plus.de/

### Download the guide

```sh
npm run grab -- --site=hd-plus.de
```

### Test

```sh
npm test -- hd-plus.de
```
