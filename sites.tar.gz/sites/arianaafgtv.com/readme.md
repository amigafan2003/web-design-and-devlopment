# arianaafgtv.com

https://arianaafgtv.com/#ariana-afghanistan-television-tv-guide

### Download the guide

```sh
npm run grab -- --site=arianaafgtv.com
```

### Test

```sh
npm test -- arianaafgtv.com
```
