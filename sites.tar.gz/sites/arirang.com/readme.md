# arirang.com

https://arirang.com/schedule

### Download the guide

```sh
npm run grab -- --site=arirang.com
```

### Test

```sh
npm test -- arirang.com
```
