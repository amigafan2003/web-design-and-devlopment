# getafteritmedia.com

https://www.getafteritmedia.com/guia_tv/completa

### Download the guide

```sh
npm run grab -- --site=getafteritmedia.com
```

### Test

```sh
npm test -- getafteritmedia.com
```
