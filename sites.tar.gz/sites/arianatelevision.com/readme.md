# arianatelevision.com

https://www.arianatelevision.com/program-schedule/

### Download the guide

```sh
npm run grab -- --site=arianatelevision.com
```

### Test

```sh
npm test -- arianatelevision.com
```
